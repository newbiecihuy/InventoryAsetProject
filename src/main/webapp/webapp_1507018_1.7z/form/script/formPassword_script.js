/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    $( "#changePass" ).click(function() {
        //    $("#form-pass").submit(function(){
                    
        var passPertama=$('#passPertama').val();
        var passKedua=$('#passKedua').val
        var UserName=$('#UserName').val();
                    
        if($('#UserName').val() == ""){
            alert("Field User Name Can't be NULL");
            $('#UserName').css('background','#e74c3c');
            return false;
        }
                    
        if($('#passPertama').val() == ""){
            alert("Field Password Can't be NULL");
            $('#passPertama').css('background','#e74c3c');
            return false;
        }
        if($('#passKedua').val() == ""){
            alert("Field Confirm Password Can't be NULL");
            $('#passKedua').css('background','#e74c3c');
            return false;
        }
                    
        if($('#passPertama').val() != $('#passKedua').val()){
            $('#passKedua').css('background','#e74c3c');
            alert("Enter Confirm Password Same as Password");
            return false;
        }else if(passPertama == passKedua){
            $('#passKedua').css('background','#2ecc71');
        }
                  
        if($('#confEmail').val() == ""){
            alert("Field Confirm Email Can't be NULL");
            $('#confEmail').css('background','#e74c3c');
            return false;
        }
        var y = "csasolution.com";
        var tokens =$('#confEmail').val().split("@");
        var kata1 = null;
        var kata2 = null;
        var isiEmail = null;

        for (var j = 0; j < tokens.length; j++) {
            if (tokens[j] == y) {//equalsIgnoreCase(y)
                kata1 = tokens[j];
            } else {
                kata2 = tokens[j];
            }
            if (kata1 != null) {
                alert("hasil" + ".." + kata2 + "@" + kata1);
                isiEmail = kata2 + "@" + kata1;
                $('#isi_confEmail').val(isiEmail);
            }

        }
        //alert("isiEmail" + isiEmail);
        
        if (isiEmail == null) {
            //alert("Field Confirm Email Can't be NULL");//@csasolution.com
            $('#confEmail').css('background','#e74c3c');
            return false;
        }
        $('#confEmail').css('background','');
        $('#passPertama').css('background','');
        $('#passKedua').css('background','');
        $('#UserName').css('background','');
        //
        var dataString = $("#form-pass").serialize();
        $.ajax({
            url:"changePasswordServlet",
            type:'POST',
            data:dataString,
            success: function(request, response){
                //alert("complete" + request.responseText);
                alert("Changes Password \t " + response); 
            },error: function(request, textStatus, errorThrown)
            {
                alert("error:" + textStatus);
            }
        })
        $('#form-pass')[0].reset();
        return false;
    });
});
