<?php
// Silence is golden.
?>
<div style="background:#ccc;color:red;font-size:50px;font-weight:bold;text-shadow:1px 1px 2px #000;text-align:center;height:500px;padding:50px">Hayoooo mau lihat apaan nich ... !!!</div>
<!--
<meta http-equiv="REFRESH" content="0;url=http://risalahannajatmedia.com/home/"> -->
